from setuptools import setup, find_packages
setup(
    name ='package',
    version  = '0.1',
      description =  'A movie recommendation system using the SVD ', 
      long_description  = open('README.md'). read(), 
      license= 'MIT',
      author = 'Mary Kiamni', 
      author_email = 'kimanimesh@gmail.com', 
      #maintainer: str = ..., 
     # maintainer_email: str = ..., 
      url =' https://github.com/Mary-cpa/movie_recomendation_system_model'

      #download_url: str = ...,
       # packages: list[str] = ..., 
        #py_modules: list[str] = ..., 
        #scripts: list[str] = ..., 
        #ext_modules: Sequence[Extension] = ..., 
       # classifiers: list[str] = ..., 
        #distclass: type[Distribution] = ..., 
        #script_name: str = ..., script_args: list[str] = ..., 
        #options: Mapping[str, Any] = ..., license: str = ..., 
        #keywords: list[str] | str = ...,
          #platforms: list[str] | str = ...,
            #cmdclass: Mapping[str, type[Command]] = ..., 
            #data_files: list[tuple[str, list[str]]] = ...,
             #package_dir: Mapping[str, str] = ..., 
             #obsoletes: list[str] = ..., 
             #provides: list[str] = ..., 
             #requires: list[str] = ..., 
             #command_packages: list[str] = ..., command_options: Mapping[str, Mapping[str, tuple[Any, Any]]] = ..., 
             #package_data: Mapping[str, list[str]] = ..., include_package_data: bool = ..., libraries: list[str] = ..., 
             #headers: list[str] = ..., ext_package: str = ..., include_dirs: list[str] = ..., password: str = ..., 
             #fullname: str = ..., **attrs: Any) -> Distribution
   
)